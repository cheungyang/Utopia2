<?php
class Success extends PHPUnit_Framework_TestCase
{
    public function runTest()
    {
    }
}
?>
