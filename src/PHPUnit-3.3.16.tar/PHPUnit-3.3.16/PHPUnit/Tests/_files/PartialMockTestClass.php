<?php
class PartialMockTestClass
{
    public function doSomething()
    {
    }

    public function doAnotherThing()
    {
    }
}
?>
